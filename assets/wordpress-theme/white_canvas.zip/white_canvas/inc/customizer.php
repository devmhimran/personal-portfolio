<?php
/**
 * White Canvas Theme Customizer
 *
 * @package White_Canvas
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */

        require_once get_theme_file_path( '/lib/kirki/kirki.php' );


        Kirki::add_config( 'white_canvas_customizer', array(
            'capability'    => 'edit_theme_options',
            'option_type'   => 'option',
        ) );

        Kirki::add_panel( 'white_canvas_theme_options', array(
            'priority'    => 10,
            'title'       => esc_html__( 'White Canvas Options', 'white_canvas' ),

        ) );


        Kirki::add_section( 'white_canvas_brand_color_settings', array(
            'title'          => esc_html__( 'Brand Color', 'white_canvas' ),
            'panel'          => 'white_canvas_theme_options',
            'priority'       => 10,
        ) );

        Kirki::add_field( 'white_canvas_customizer', [
            'type'        => 'color',
            'settings'    => 'white_canvas_brand_color_setting',
            'label'       => __( 'Brand Color', 'kirki' ),
            'description' => esc_html__( 'This is a color control - without alpha channel.', 'kirki' ),
            'section'     => 'white_canvas_brand_color_settings',
            'default'     => '#f5efe0',
            'output' => array(
                array(
                    'element'  => '.nav',
                    'property' => 'background-color',
                ),
                array(
                    'element'  => '.pages-hero',
                    'property' => 'background-color',
                ),
            ),
        ] );

        Kirki::add_section( 'white_canvas_typography_settings', array(
            'title'          => esc_html__( 'Header typography', 'white_canvas' ),
            'panel'          => 'white_canvas_theme_options',
            'priority'       => 20,
        ) );
        Kirki::add_field( 'white_canvas_customizer', [
            'type'        => 'typography',
            'settings'    => 'white_canvas_typography_setting',
            'label'       => esc_html__( 'Navbar Typography', 'kirki' ),
            'section'     => 'white_canvas_typography_settings',
            'default'     => [
                'font-family'    => 'Montserrat',
                'variant'        => 'regular',
                'font-size'      => '16px',
                'line-height'    => '1.5',
                'letter-spacing' => '0',
                'color'          => '#262524',
                'text-transform' => 'none',
                'text-align'     => 'left',
            ],
            'priority'    => 10,
            'transport'   => 'auto',
            'output'      => [
                [
                    'element' => '.nav-link span',
                ],
            ],
        ] );
        Kirki::add_field( 'white_canvas_customizer', [
            'type'        => 'color',
            'settings'    => 'white_canvas_navnar_hover_setting',
            'label'       => __( 'Navbar Link Hover Color', 'kirki' ),
            'section'     => 'white_canvas_typography_settings',
            'default'     => '#FF493C',
            'transport'   => 'auto',
            'output'      => [
                [
                    'element' => '.nav-link span:hover',
                    'property' => 'color'
                ],
            ],
            'priority'    => 20,
        ] );


        // White Canvas Hero Background Settings

            Kirki::add_section( 'white_canvas_hero_typography_settings', array(
                        'title'          => esc_html__( 'Hero Typography', 'white_canvas' ),
                        'panel'          => 'white_canvas_theme_options',
                        'priority'       => 30,
                    ) );

                Kirki::add_field( 'white_canvas_customizer', [
                    'type'        => 'typography',
                    'settings'    => 'white_canvas_hero_typography_setting',
                    'label'       => esc_html__( 'Hero Typography', 'kirki' ),
                    'section'     => 'white_canvas_hero_typography_settings',
                    'default'     => [
                        'font-family'    => 'Montserrat',
                        'variant'        => '500',
                        'font-size'      => '42px',
                        'line-height'    => '1.5',
                        'letter-spacing' => '0',
                        'color'          => '#262524',
                        'text-transform' => 'none',
                        'text-align'     => 'center',
                    ],
                    'priority'    => 10,
                    'transport'   => 'auto',
                    'output'      => [
                        [
                            'element' => '.entry-title',
                        ],
                    ],
                ] );