<?php

function ocdi_import_files() {
	return array(
		array(
			'import_file_name'           => 'Barbar Service',
			// 'categories'                 => array( 'Category 1', 'Category 2' ),
			'import_file_url'            => 'https://dl.dropboxusercontent.com/s/d1n5bb26nsl8lq9/barber.WordPress.2021-04-14.xml',
			'import_preview_image_url'   => 'https://themespell.com/wp-content/uploads/2021/07/localpress_holiday_decoration.png',
			'import_notice'              => __( 'After you import this demo, you will have to setup the slider separately.', 'your-textdomain' ),
			'preview_url'                => 'https://preview.themespell.com/localpress-holiday-decoration-service/',
		),
        array(
			'import_file_name'           => 'Holiday Decoration Service',
			// 'categories'                 => array( 'Category 1', 'Category 2' ),
			'import_file_url'            => 'https://dl.dropboxusercontent.com/s/313umwml79yfd0s/petzone.WordPress.2021-02-18.xml',
			'import_preview_image_url'   => 'https://themespell.com/wp-content/uploads/2021/07/localpress_holiday_decoration.png',
			'import_notice'              => __( 'After you import this demo, you will have to setup the slider separately.', 'your-textdomain' ),
			'preview_url'                => 'https://preview.themespell.com/localpress-holiday-decoration-service/',
		),

	);
}
add_filter( 'ocdi/import_files', 'ocdi_import_files' );