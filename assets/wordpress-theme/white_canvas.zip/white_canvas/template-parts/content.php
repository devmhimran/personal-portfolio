<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package White_Canvas
 */

?>

 		
 			<div class="col-md-6">
 				<div class="card" >
  				<?php

  					if (has_post_thumbnail()) {
  						the_post_thumbnail("class='card-img-top'");
  					}

  				?>
  				<div class="card-body">
    				<h5 class="card-title">
    					<?php

    					if ( is_singular() ) :
							the_title();
						else :
							the_title( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a>' );
						endif;

    					?>
    					
    				</h5>
    					<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    					<a href="<?php echo esc_url( get_permalink()) ?>" class="card-btn">Read More</a>
 				 </div>
			</div>
 			</div>
 	
